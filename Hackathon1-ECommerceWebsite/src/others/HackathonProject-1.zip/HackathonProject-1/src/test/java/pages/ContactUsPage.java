package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactUsPage {

    WebDriver driver;

    @FindBy(xpath = "//h2[contains(text(),'Get In Touch')]")
    WebElement heading;

    @FindBy(name = "name")
    WebElement name;

    @FindBy(name = "email")
    WebElement email;

    @FindBy(name = "subject")
    WebElement subject;

    @FindBy(name = "message")
    WebElement message;

    @FindBy(name = "upload_file")
    WebElement uploadFile;

    @FindBy(name = "submit")
    WebElement submitBtn;

    @FindBy(xpath = "//div[@class='status alert alert-success']")
    WebElement successMsg;

    public ContactUsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public boolean isHeadingDisplayed() {
        return heading.isDisplayed();
    }

    public void fillForm(String uname, String uemail,
                         String usubject, String umessage,
                         String filePath) {

        name.sendKeys(uname);
        email.sendKeys(uemail);
        subject.sendKeys(usubject);
        message.sendKeys(umessage);
        uploadFile.sendKeys(filePath);
    }

    public void submitForm() {
        submitBtn.click();
        Alert alert = driver.switchTo().alert();
        alert.accept();
    }

    public String getSuccessMessage() {
        return successMsg.getText();
    }
}
