package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

    WebDriver driver;

    @FindBy(xpath = "//a[contains(text(),'Contact us')]")
    WebElement contactUsBtn;

    @FindBy(xpath = "//a[contains(text(),'Test Cases')]")
    WebElement testCasesBtn;

    @FindBy(xpath = "//a[contains(text(),'Products')]")
    WebElement productsBtn;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickContactUs() {
        contactUsBtn.click();
    }

    public void clickTestCases() {
        testCasesBtn.click();
    }

    public void clickProducts() {
        productsBtn.click();
    }
}
