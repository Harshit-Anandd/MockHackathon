package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class ProductsPage {

    WebDriver driver;

    @FindBy(xpath = "//h2[contains(text(),'All Products')]")
    WebElement allProductsTitle;

    @FindBy(xpath = "(//a[contains(text(),'View Product')])[1]")
    WebElement firstViewProduct;

    @FindBy(xpath = "//div[@class='product-information']/h2")
    WebElement productName;

    @FindBy(id = "search_product")
    WebElement searchBox;

    @FindBy(id = "submit_search")
    WebElement searchBtn;

    @FindBy(xpath = "//h2[contains(text(),'Searched Products')]")
    WebElement searchedProductsTitle;

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public boolean isAllProductsVisible() {
        return allProductsTitle.isDisplayed();
    }

    public void clickFirstProduct() {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", firstViewProduct);

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(firstViewProduct));

        firstViewProduct.click();
    }


    public boolean isProductDetailVisible() {
        return productName.isDisplayed();
    }

    public void searchProduct(String product) {
        searchBox.sendKeys(product);
        searchBtn.click();
    }

    public boolean isSearchResultVisible() {
        return searchedProductsTitle.isDisplayed();
    }
}
