package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SubscriptionSection {

    WebDriver driver;

    @FindBy(xpath = "//h2[contains(text(),'Subscription')]")
    WebElement subscriptionText;

    @FindBy(id = "susbscribe_email")
    WebElement emailField;

    @FindBy(id = "subscribe")
    WebElement subscribeBtn;

    @FindBy(xpath = "//div[contains(text(),'You have been successfully subscribed!')]")
    WebElement successMsg;

    public SubscriptionSection(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void scrollToFooter() {
        JavascriptExecutor js =
                (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }

    public boolean isSubscriptionVisible() {
        return subscriptionText.isDisplayed();
    }

    public void subscribe(String email) {
        emailField.sendKeys(email);
        subscribeBtn.click();
    }

    public boolean isSuccessDisplayed() {
        return successMsg.isDisplayed();
    }
}
