package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ContactUsPage;
import pages.HomePage;

public class ContactUsTest extends BaseTest {

    @Test
    public void verifyContactUsForm() {

        HomePage home = new HomePage(driver);
        home.clickContactUs();

        ContactUsPage contact = new ContactUsPage(driver);

        Assert.assertTrue(contact.isHeadingDisplayed());

        contact.fillForm(
                "Goldy",
                "test@gmail.com",
                "Automation",
                "Testing contact form",
                "d:\\Hackathon\\testfile.txt"
        );

        contact.submitForm();

        Assert.assertTrue(contact.getSuccessMessage()
                .contains("Success"));
    }
}
