package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.ProductsPage;

public class ProductsTest extends BaseTest {

    @Test(priority = 1,
            description = "Verify All Products page and product detail page")
    public void verifyAllProductsAndProductDetails() {

        // Step 1: Navigate to Products page
        HomePage homePage = new HomePage(driver);
        homePage.clickProducts();

        // Step 2: Initialize Products Page
        ProductsPage productsPage = new ProductsPage(driver);

        // Step 3: Verify 'All Products' page is visible
        Assert.assertTrue(
                productsPage.isAllProductsVisible(),
                "All Products page is NOT visible"
        );

        // Step 4: Click first product
        productsPage.clickFirstProduct();

        // Step 5: Verify product detail page
        Assert.assertTrue(
                productsPage.isProductDetailVisible(),
                "Product detail page is NOT displayed"
        );
    }
}
