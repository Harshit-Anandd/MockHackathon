package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.ProductsPage;

public class SearchProductTest extends BaseTest {

    @Test(priority = 2,
            description = "Verify user is able to search product successfully")
    public void verifySearchProduct() {

        // Step 1: Navigate to Products page
        HomePage homePage = new HomePage(driver);
        homePage.clickProducts();

        // Step 2: Initialize Products Page
        ProductsPage productsPage = new ProductsPage(driver);

        // Step 3: Search product
        productsPage.searchProduct("Tshirt");

        // Step 4: Verify searched results displayed
        Assert.assertTrue(
                productsPage.isSearchResultVisible(),
                "Searched products are NOT displayed"
        );
    }
}
