package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.SubscriptionSection;

public class SubscriptionTest extends BaseTest {

    @Test(priority = 1,
            description = "Verify user is able to subscribe from home page")
    public void verifySubscriptionInHomePage() {

        // Step 1: Initialize Subscription Section
        SubscriptionSection subscription = new SubscriptionSection(driver);

        // Step 2: Scroll to footer
        subscription.scrollToFooter();

        // Step 3: Verify Subscription text is visible
        Assert.assertTrue(
                subscription.isSubscriptionVisible(),
                "Subscription section is NOT visible"
        );

        // Step 4: Enter email and subscribe
        subscription.subscribe("test123@gmail.com");

        // Step 5: Verify success message
        Assert.assertTrue(
                subscription.isSuccessDisplayed(),
                "Subscription success message NOT displayed"
        );
    }
}
