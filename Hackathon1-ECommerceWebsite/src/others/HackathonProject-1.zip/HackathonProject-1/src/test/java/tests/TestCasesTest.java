package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.TestCasesPage;

public class TestCasesTest extends BaseTest {

    @Test(priority = 1,
            description = "Verify that user is able to navigate to Test Cases page")
    public void verifyTestCasesPage() {

        // Step 1: Initialize Home Page
        HomePage homePage = new HomePage(driver);

        // Step 2: Click on Test Cases button
        homePage.clickTestCases();

        // Step 3: Initialize Test Cases Page
        TestCasesPage testCasesPage = new TestCasesPage(driver);

        // Step 4: Verify heading is visible
        Assert.assertTrue(
                testCasesPage.isHeadingVisible(),
                "Test Cases heading is NOT visible"
        );
    }
}
