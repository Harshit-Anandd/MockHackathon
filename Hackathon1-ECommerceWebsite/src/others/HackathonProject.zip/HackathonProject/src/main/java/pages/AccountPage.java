package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AccountPage {

    WebDriver driver;

    public AccountPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//a[contains(text(),'Delete Account')]")
    WebElement deleteAccountBtn;

    @FindBy(xpath = "//b[contains(text(),'Account Deleted!')]")
    WebElement accountDeletedMessage;

    @FindBy(xpath = "//a[contains(text(),'Continue')]")
    WebElement continueBtn;

    public void clickDeleteAccount() {
        deleteAccountBtn.click();
    }

    public boolean isAccountDeletedVisible() {
        return accountDeletedMessage.isDisplayed();
    }

    public void clickContinue() {
        continueBtn.click();
    }
}
