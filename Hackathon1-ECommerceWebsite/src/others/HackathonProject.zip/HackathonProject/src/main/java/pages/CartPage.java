package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;


public class CartPage {

    WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Cart page heading
    @FindBy(xpath = "//li[contains(text(),'Shopping Cart')]")
    WebElement cartHeading;

    // Proceed to Checkout button
    @FindBy(xpath = "//a[contains(text(),'Proceed To Checkout')]")
    WebElement proceedToCheckoutBtn;

    // Delete (X) button for first product
    @FindBy(xpath = "//a[@class='cart_quantity_delete']")
    WebElement deleteProductBtn;

    @FindBy(xpath = "//b[contains(text(),'Cart is empty!')]")
    WebElement emptyCartMessage;

    public boolean isCartPageDisplayed() {
        return cartHeading.isDisplayed();
    }

    public void clickProceedToCheckout() {
        proceedToCheckoutBtn.click();
    }

    public void clickDeleteProduct() {
        deleteProductBtn.click();
    }

    public boolean isCartEmpty() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(emptyCartMessage));
        return emptyCartMessage.isDisplayed();
    }


}
