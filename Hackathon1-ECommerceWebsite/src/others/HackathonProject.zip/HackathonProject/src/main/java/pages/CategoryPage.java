package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CategoryPage {

    WebDriver driver;

    public CategoryPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Left sidebar category section
    @FindBy(xpath = "//h2[contains(text(),'Category')]")
    WebElement categorySidebar;

    // Women category
    @FindBy(xpath = "//a[@href='#Women']")
    WebElement womenCategory;

    // Women → Dress subcategory
    @FindBy(xpath = "//a[contains(text(),'Dress')]")
    WebElement womenDressSubCategory;

    // Men category
    @FindBy(xpath = "//a[@href='#Men']")
    WebElement menCategory;

    // Men → Tshirts subcategory
    @FindBy(xpath = "//a[contains(text(),'Tshirts')]")
    WebElement menTshirtsSubCategory;

    // Category page title
    @FindBy(xpath = "//h2[@class='title text-center']")
    WebElement categoryTitle;

    public boolean isCategorySidebarVisible() {
        return categorySidebar.isDisplayed();
    }

    public void clickWomenCategory() {
        womenCategory.click();
    }

    public void clickWomenDress() {
        womenDressSubCategory.click();
    }

    public void clickMenCategory() {
        menCategory.click();
    }

    public void clickMenTshirts() {
        menTshirtsSubCategory.click();
    }

    public String getCategoryTitle() {
        return categoryTitle.getText();
    }
}
