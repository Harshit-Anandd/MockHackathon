package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckoutPage {

    WebDriver driver;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }


    // Address Details section
    @FindBy(xpath = "//h2[contains(text(),'Address Details')]")
    WebElement addressDetailsHeading;

    // Review Your Order section
    @FindBy(xpath = "//h2[contains(text(),'Review Your Order')]")
    WebElement reviewOrderHeading;

    // Comment text area
    @FindBy(name = "message")
    WebElement commentBox;

    // Place Order button
    @FindBy(xpath = "//a[contains(text(),'Place Order')]")
    WebElement placeOrderBtn;


    public boolean isAddressDetailsVisible() {
        return addressDetailsHeading.isDisplayed();
    }

    public boolean isReviewOrderVisible() {
        return reviewOrderHeading.isDisplayed();
    }

    public void enterComment(String comment) {
        commentBox.sendKeys(comment);
    }

    public void clickPlaceOrder() {
        placeOrderBtn.click();
    }
}
