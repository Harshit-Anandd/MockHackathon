package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

    WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//img[@alt='Website for automation practice']")
    WebElement logo;

    @FindBy(xpath = "//a[contains(text(),'Signup / Login')]")
    WebElement signupLoginBtn;

    @FindBy(xpath = "(//a[contains(text(),'Add to cart')])[1]")
    WebElement firstAddToCartBtn;

    @FindBy(xpath = "//a[contains(text(),'Cart')]")
    WebElement cartBtn;

    @FindBy(xpath = "//button[contains(text(),'Continue Shopping')]")
    WebElement continueShoppingBtn;

    @FindBy(xpath = "//u[contains(text(),'View Cart')]")
    WebElement viewCartBtn;

    public boolean isHomePageVisible() {
        return logo.isDisplayed();
    }

    public void clickSignupLogin() {
        signupLoginBtn.click();
    }

    public void addFirstProductToCart() {
        firstAddToCartBtn.click();
    }

    public void clickCart() {
        cartBtn.click();
    }

    public void clickContinueShopping() {
        continueShoppingBtn.click();
    }

}
