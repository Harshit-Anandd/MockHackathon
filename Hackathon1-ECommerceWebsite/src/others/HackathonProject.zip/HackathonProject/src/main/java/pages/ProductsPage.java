package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.JavascriptExecutor;

import java.util.List;

public class ProductsPage {

    WebDriver driver;

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ---------------- Web Elements ----------------

    // Products button on top menu
    @FindBy(xpath = "//a[contains(text(),'Products')]")
    WebElement productsBtn;

    // Brands sidebar heading
    @FindBy(xpath = "//h2[contains(text(),'Brands')]")
    WebElement brandsSidebar;

    // Example Brand 1 (Polo)
    @FindBy(xpath = "//a[@href='/brand_products/Polo']")
    WebElement poloBrand;

    // Example Brand 2 (H&M)
    @FindBy(xpath = "//a[@href='/brand_products/H&M']")
    WebElement hmBrand;

    // Brand page title
    @FindBy(xpath = "//h2[@class='title text-center']")
    WebElement brandTitle;

    // Search input
    @FindBy(id = "search_product")
    WebElement searchInput;

    // Search button
    @FindBy(id = "submit_search")
    WebElement searchBtn;

    // SEARCHED PRODUCTS title
    @FindBy(xpath = "//h2[contains(text(),'Searched Products')]")
    WebElement searchedProductsTitle;

    // Product list after search
    @FindBy(xpath = "//div[@class='productinfo text-center']")
    List<WebElement> searchedProducts;

    // Add to cart button (first searched product)
    @FindBy(xpath = "(//a[contains(text(),'Add to cart')])[1]")
    WebElement firstAddToCart;


    // ---------------- Methods ----------------

    public void clickProducts() {
        productsBtn.click();
    }

    public boolean isBrandsSidebarVisible() {
        return brandsSidebar.isDisplayed();
    }

    public void clickPoloBrand() {
        // Scroll to element first (optional but good practice)
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", poloBrand);
        // Then JS click to bypass ad overlay
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", poloBrand);
    }



    public void clickHMBrand() {
        // Scroll into view first
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", hmBrand);
        // Use JavaScript click to bypass ad overlay
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", hmBrand);
    }


    public String getBrandTitle() {
        return brandTitle.getText();
    }

    public void searchProduct(String productName) {
        searchInput.sendKeys(productName);
        searchBtn.click();
    }

    public boolean isSearchedProductsVisible() {
        return searchedProductsTitle.isDisplayed();
    }

    public int getSearchedProductsCount() {
        return searchedProducts.size();
    }

    public void addFirstSearchedProductToCart() {
        ((JavascriptExecutor) driver)
                .executeScript("arguments[0].click();", firstAddToCart);
    }

}
