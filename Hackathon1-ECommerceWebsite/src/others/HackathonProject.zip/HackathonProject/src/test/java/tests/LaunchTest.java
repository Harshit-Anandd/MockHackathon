package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;

public class LaunchTest extends BaseTest {

    @Test
    public void verifyHomePageLaunch() {
        HomePage homePage = new HomePage(driver);
        Assert.assertTrue(homePage.isHomePageVisible(),"Home page is not visible");
    }
}
