package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;

public class LoginTest extends BaseTest {

    @Test
    public void verifyUserLogin() {

        HomePage homePage = new HomePage(driver);

        // Step 1: Verify home page visible
        Assert.assertTrue(homePage.isHomePageVisible(),"Home page is not visible");

        // Step 2: Click Signup/Login
        homePage.clickSignupLogin();

        LoginPage loginPage = new LoginPage(driver);

        // Step 3: Login
        loginPage.login("testuser11234@gmail.com", "00000000");

        // Step 4: Verify Logged in
        Assert.assertTrue(loginPage.isLoggedInVisible(),"Login failed - Logged in text not visible");
    }
}

