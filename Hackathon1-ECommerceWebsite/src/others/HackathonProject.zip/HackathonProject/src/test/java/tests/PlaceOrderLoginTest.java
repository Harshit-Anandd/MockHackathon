package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class PlaceOrderLoginTest extends BaseTest {

    @Test
    public void placeOrderLoginFlow() {

        HomePage homePage = new HomePage(driver);

        Assert.assertTrue(homePage.isHomePageVisible(),
                "Home page not visible");

        homePage.clickSignupLogin();

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("testuser11234@gmail.com", "00000000");

        Assert.assertTrue(loginPage.isLoggedInVisible(),
                "Login failed");

        homePage.addFirstProductToCart();
        homePage.clickContinueShopping();
        homePage.clickCart();

        CartPage cartPage = new CartPage(driver);
        Assert.assertTrue(cartPage.isCartPageDisplayed(),
                "Cart page not displayed");

        cartPage.clickProceedToCheckout();

        CheckoutPage checkoutPage = new CheckoutPage(driver);

        Assert.assertTrue(checkoutPage.isAddressDetailsVisible(),
                "Address not visible");

        Assert.assertTrue(checkoutPage.isReviewOrderVisible(),
                "Review order not visible");

        checkoutPage.enterComment("Test automation order");
        checkoutPage.clickPlaceOrder();

        PaymentPage paymentPage = new PaymentPage(driver);
        paymentPage.enterPaymentDetails();
        paymentPage.clickPayAndConfirm();

        Assert.assertTrue(paymentPage.isOrderSuccessVisible(),
                "Order success message not visible");

        AccountPage accountPage = new AccountPage(driver);
        accountPage.clickDeleteAccount();

        Assert.assertTrue(accountPage.isAccountDeletedVisible(),
                "Account delete failed");

        accountPage.clickContinue();
    }
}
