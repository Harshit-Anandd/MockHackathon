package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.HomePage;

public class RemoveProductTest extends BaseTest {

    @Test
    public void removeProductFromCart() {

        HomePage homePage = new HomePage(driver);

        // Step 1-3: Verify home page
        Assert.assertTrue(homePage.isHomePageVisible(),"Home page not visible");

        // Step 4: Add product
        homePage.addFirstProductToCart();
        homePage.clickContinueShopping();

        // Step 5: Click Cart
        homePage.clickCart();

        CartPage cartPage = new CartPage(driver);

        // Step 6: Verify cart page
        Assert.assertTrue(cartPage.isCartPageDisplayed(),"Cart page not displayed");

        // Step 7: Remove product
        cartPage.clickDeleteProduct();

        // Step 8: Verify product removed
        Assert.assertTrue(cartPage.isCartEmpty(),"Product was not removed from cart");
    }
}
