package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class SearchAndCartAfterLoginTest extends BaseTest {

    @Test
    public void searchProductAndVerifyCartAfterLogin() {

        HomePage homePage = new HomePage(driver);
        ProductsPage productsPage = new ProductsPage(driver);

        // Step 3: Click Products
        productsPage.clickProducts();

        // Step 4: Verify ALL PRODUCTS page
        Assert.assertTrue(driver.getCurrentUrl().contains("products"),"Not navigated to ALL PRODUCTS page");

        // Step 5: Search product
        productsPage.searchProduct("Tshirt");

        // Step 6: Verify SEARCHED PRODUCTS visible
        Assert.assertTrue(productsPage.isSearchedProductsVisible(),"Searched Products title not visible");

        // Step 7: Verify products related to search
        Assert.assertTrue(productsPage.getSearchedProductsCount() > 0,"No searched products found");

        // Step 8: Add searched product to cart
        productsPage.addFirstSearchedProductToCart();
        homePage.clickContinueShopping();

        // Step 9: Go to Cart & verify
        homePage.clickCart();
        CartPage cartPage = new CartPage(driver);

        Assert.assertTrue(cartPage.isCartPageDisplayed(),
                "Cart page not displayed");

        // Step 10: Login
        homePage.clickSignupLogin();
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("usertest12345@gmail.com", "789456123");

        Assert.assertTrue(loginPage.isLoggedInVisible(),
                "Login failed");

        // Step 11: Go back to Cart
        homePage.clickCart();

        // Step 12: Verify product still in cart
        Assert.assertTrue(cartPage.isCartPageDisplayed(),"Products not visible after login");
    }
}
