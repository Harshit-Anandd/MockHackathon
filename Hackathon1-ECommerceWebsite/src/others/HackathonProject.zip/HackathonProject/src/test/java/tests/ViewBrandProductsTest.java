package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ProductsPage;

public class ViewBrandProductsTest extends BaseTest {

    @Test
    public void viewBrandProductsTest() {

        ProductsPage productsPage = new ProductsPage(driver);

        // Step 3: Click Products
        productsPage.clickProducts();

        // Step 4: Verify Brands visible
        Assert.assertTrue(productsPage.isBrandsSidebarVisible(),"Brands sidebar not visible");

        // Step 5: Click Polo brand
        productsPage.clickPoloBrand();

        // Step 6: Verify Polo brand page
        String poloTitle = productsPage.getBrandTitle();
        System.out.println("Brand Title: " + poloTitle);

        Assert.assertTrue(poloTitle.contains("POLO"),"Polo brand page not displayed");

        // Step 7: Click H&M brand
        productsPage.clickHMBrand();

        // Step 8: Verify H&M brand page
        String hmTitle = productsPage.getBrandTitle();
        System.out.println("Brand Title: " + hmTitle);

        Assert.assertTrue(hmTitle.contains("H&M"),"H&M brand page not displayed");
    }
}
