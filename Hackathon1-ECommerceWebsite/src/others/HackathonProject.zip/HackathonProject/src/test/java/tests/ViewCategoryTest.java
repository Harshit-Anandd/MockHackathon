package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CategoryPage;
import pages.HomePage;

public class ViewCategoryTest extends BaseTest {

    @Test
    public void viewCategoryProductsTest() {

        HomePage homePage = new HomePage(driver);

        // Step 3: Verify categories visible
        CategoryPage categoryPage = new CategoryPage(driver);

        Assert.assertTrue(categoryPage.isCategorySidebarVisible(),
                "Category sidebar not visible");

        // Step 4: Click Women
        categoryPage.clickWomenCategory();

        // Step 5: Click Dress
        categoryPage.clickWomenDress();

        // Step 6: Verify Women category page
        String womenTitle = categoryPage.getCategoryTitle();
        System.out.println("Women Category Title: " + womenTitle);

        Assert.assertTrue(womenTitle.contains("WOMEN"),
                "Women category page not displayed");

        // Step 7: Click Men category
        categoryPage.clickMenCategory();
        categoryPage.clickMenTshirts();

        // Step 8: Verify Men category page
        String menTitle = categoryPage.getCategoryTitle();
        System.out.println("Men Category Title: " + menTitle);

        Assert.assertTrue(menTitle.contains("MEN"),
                "Men category page not displayed");
    }
}
