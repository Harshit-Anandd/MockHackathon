package pages;
import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class CartPage {
    WebDriver driver;
    WebDriverWait wait;

    public CartPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
        wait = new WebDriverWait(driver,Duration.ofSeconds(10));
    }

    @FindBy(xpath = "//a[@href='/view_cart']")
    WebElement cartButton;

    @FindBy(xpath = "//h2[text()='Subscription']")
    WebElement subscriptionHeader;

    @FindBy(id = "susbscribe_email")
    WebElement emailInput;

    @FindBy(id = "subscribe")
    WebElement subscribeButton;

    @FindBy(xpath = "//div[@class='alert-success alert']")
    WebElement successMessage;

    public void clickCart() {
        cartButton.click();
    }

        public void scrollToSubscription() {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView(true);", subscriptionHeader);
        }

        public boolean isSubscriptionVisible() {
            return subscriptionHeader.isDisplayed();
        }

        public void enterEmail(String email) {
            emailInput.sendKeys(email);
        }

        public void clickSubscribe() {
            subscribeButton.click();
        }

        public boolean isSuccessMessageVisible() {
            wait.until(ExpectedConditions.visibilityOf(successMessage));
            return successMessage.isDisplayed();
        }
    }

