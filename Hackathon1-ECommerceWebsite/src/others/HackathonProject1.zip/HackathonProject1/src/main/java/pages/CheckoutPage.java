package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class CheckoutPage {

    WebDriver driver;
    WebDriverWait wait;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @FindBy(xpath = "//a[text()='Proceed To Checkout']")
    WebElement proceedToCheckout;

    @FindBy(name = "message")
    WebElement commentBox;

    @FindBy(xpath = "//a[text()='Place Order']")
    WebElement placeOrderButton;

    @FindBy(name = "name_on_card")
    WebElement nameOnCard;

    @FindBy(name = "card_number")
    WebElement cardNumber;

    @FindBy(name = "cvc")
    WebElement cvc;

    @FindBy(name = "expiry_month")
    WebElement expiryMonth;

    @FindBy(name = "expiry_year")
    WebElement expiryYear;

    @FindBy(id = "submit")
    WebElement payButton;

    @FindBy(xpath = "//p[contains(text(),'Your order has been placed successfully')]")
    WebElement successMessage;

    public void proceedToCheckout() {
        proceedToCheckout.click();
    }

    public void placeOrder() {
        commentBox.sendKeys("Test Order");
        placeOrderButton.click();
    }

    public void enterPaymentDetails() {
        nameOnCard.sendKeys("Ishan");
        cardNumber.sendKeys("1234567812345678");
        cvc.sendKeys("123");
        expiryMonth.sendKeys("12");
        expiryYear.sendKeys("2028");
        payButton.click();
    }

    public boolean isOrderSuccessful() {
        wait.until(ExpectedConditions.visibilityOf(successMessage));
        return successMessage.isDisplayed();
    }
}
