package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class ProductPage {

    WebDriver driver;
    WebDriverWait wait;

    public ProductPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @FindBy(xpath = "//a[@href='/products']")
    WebElement productsButton;

    @FindBy(xpath = "(//a[contains(text(),'Add to cart')])[1]")
    WebElement firstAddToCartButton;

    @FindBy(xpath = "//button[text()='Continue Shopping']")
    WebElement continueShoppingButton;

    @FindBy(xpath = "//a[@href='/view_cart']")
    WebElement cartButton;

    @FindBy(xpath = "//tr[@id='product-1']")
    WebElement productInCart;

    public void clickProducts() {
        productsButton.click();
    }

    public void addFirstProductToCart() {
        firstAddToCartButton.click();
        wait.until(ExpectedConditions.visibilityOf(continueShoppingButton));
        continueShoppingButton.click();
    }

    public void clickCart() {
        cartButton.click();
    }

    public boolean isProductDisplayedInCart() {
        return productInCart.isDisplayed();
    }
}
