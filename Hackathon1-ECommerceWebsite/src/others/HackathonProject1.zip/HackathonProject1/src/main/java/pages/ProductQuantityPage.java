package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class ProductQuantityPage {

    WebDriver driver;
    WebDriverWait wait;

    public ProductQuantityPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @FindBy(xpath = "//a[@href='/products']")
    WebElement productsButton;

    @FindBy(xpath = "(//a[text()='View Product'])[1]")
    WebElement firstViewProduct;

    @FindBy(id = "quantity")
    WebElement quantityInput;

    @FindBy(xpath = "//button[@type='button']")
    WebElement addToCartButton;

    @FindBy(xpath = "//u[text()='View Cart']")
    WebElement viewCartLink;

    @FindBy(xpath = "//td[@class='cart_quantity']//button")
    WebElement quantityInCart;

    public void clickProducts() {
        productsButton.click();
    }

    public void openFirstProduct() {
        firstViewProduct.click();
    }

    public void setQuantity(String qty) {
        quantityInput.clear();
        quantityInput.sendKeys(qty);
    }

    public void clickAddToCart() {
        addToCartButton.click();
    }

    public void clickViewCart() {
        wait.until(ExpectedConditions.visibilityOf(viewCartLink));
        viewCartLink.click();
    }

    public String getQuantityFromCart() {
        return quantityInCart.getText();
    }
}
