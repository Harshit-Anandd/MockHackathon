package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.Select;

public class SignupPage {

    WebDriver driver;

    public SignupPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//a[text()=' Signup / Login']")
    WebElement signupLoginButton;

    @FindBy(name = "name")
    WebElement nameField;

    @FindBy(xpath = "//input[@data-qa='signup-email']")
    WebElement emailField;

    @FindBy(xpath = "//button[@data-qa='signup-button']")
    WebElement signupButton;

    @FindBy(id = "password")
    WebElement password;

    @FindBy(id = "first_name")
    WebElement firstName;

    @FindBy(id = "last_name")
    WebElement lastName;

    @FindBy(id = "address1")
    WebElement address;

    @FindBy(id = "state")
    WebElement state;

    @FindBy(id = "city")
    WebElement city;

    @FindBy(id = "zipcode")
    WebElement zipCode;

    @FindBy(id = "mobile_number")
    WebElement mobile;

    @FindBy(xpath = "//button[@data-qa='create-account']")
    WebElement createAccountButton;

    public void clickSignupLogin() {
        signupLoginButton.click();
    }

    public void enterSignupDetails(String name, String email) {
        nameField.sendKeys(name);
        emailField.sendKeys(email);
        signupButton.click();
    }

    public void fillAccountDetails() {

        password.sendKeys("Test123");
        firstName.sendKeys("Ishan");
        lastName.sendKeys("Test");
        address.sendKeys("Test Address");
        state.sendKeys("MP");
        city.sendKeys("Indore");
        zipCode.sendKeys("452001");
        mobile.sendKeys("9999999999");

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", createAccountButton);

        createAccountButton.click();
    }

}
