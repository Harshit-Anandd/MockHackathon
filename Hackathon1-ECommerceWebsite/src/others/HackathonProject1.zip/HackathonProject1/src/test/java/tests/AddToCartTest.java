package tests;

import basetest.BaseTest;
import pages.ProductPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AddToCartTest extends BaseTest {

    @Test
    public void verifyAddProductToCart() {

        ProductPage productPage = new ProductPage(driver);

        productPage.clickProducts();
        productPage.addFirstProductToCart();
        productPage.clickCart();

        Assert.assertTrue(productPage.isProductDisplayedInCart(),
                "Product was not added to cart!");
    }
}
