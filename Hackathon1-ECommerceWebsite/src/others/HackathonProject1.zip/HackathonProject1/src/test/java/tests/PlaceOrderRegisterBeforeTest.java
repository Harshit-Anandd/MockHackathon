package tests;

import basetest.BaseTest;
import pages.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PlaceOrderRegisterBeforeTest extends BaseTest {

    @Test
    public void placeOrderRegisterBeforeCheckout() {

        SignupPage signupPage = new SignupPage(driver);
        ProductPage productPage = new ProductPage(driver);
        CheckoutPage checkoutPage = new CheckoutPage(driver);

        // 1️⃣ Register First
        signupPage.clickSignupLogin();
        signupPage.enterSignupDetails(
                "TestUser",
                "test" + System.currentTimeMillis() + "@mail.com"
        );
        signupPage.fillAccountDetails();

        // 2️⃣ Add Product
        productPage.clickProducts();
        productPage.addFirstProductToCart();
        productPage.clickCart();

        // 3️⃣ Checkout
        checkoutPage.proceedToCheckout();
        checkoutPage.placeOrder();
        checkoutPage.enterPaymentDetails();

        // 4️⃣ Verify Success
        Assert.assertTrue(checkoutPage.isOrderSuccessful(),
                "Order was not placed successfully!");
    }
}
