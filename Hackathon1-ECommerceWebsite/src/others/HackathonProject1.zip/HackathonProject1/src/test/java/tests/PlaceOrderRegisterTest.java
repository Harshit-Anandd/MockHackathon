package tests;

import basetest.BaseTest;
import pages.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PlaceOrderRegisterTest extends BaseTest {

    @Test
    public void placeOrderRegisterWhileCheckout() {

        ProductPage productPage = new ProductPage(driver);
        SignupPage signupPage = new SignupPage(driver);
        CheckoutPage checkoutPage = new CheckoutPage(driver);

        productPage.clickProducts();
        productPage.addFirstProductToCart();
        productPage.clickCart();

        checkoutPage.proceedToCheckout();

        signupPage.clickSignupLogin();
        signupPage.enterSignupDetails("TestUser", "test" + System.currentTimeMillis() + "@mail.com");
        signupPage.fillAccountDetails();

        checkoutPage.proceedToCheckout();
        checkoutPage.placeOrder();
        checkoutPage.enterPaymentDetails();

        Assert.assertTrue(checkoutPage.isOrderSuccessful(),
                "Order was not placed successfully!");
    }
}
