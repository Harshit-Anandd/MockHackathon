package tests;

import basetest.BaseTest;
import pages.CartPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SubscriptionTest extends BaseTest {

    @Test
    public void verifySubscriptionOnCartPage() {

        CartPage cartPage = new CartPage(driver);

        cartPage.clickCart();
        cartPage.scrollToSubscription();

        Assert.assertTrue(cartPage.isSubscriptionVisible(),
                "Subscription header not visible!");

        cartPage.enterEmail("test123@gmail.com");
        cartPage.clickSubscribe();

        Assert.assertTrue(cartPage.isSuccessMessageVisible(),
                "Subscription success message not visible!");
    }
}
