package tests;

import basetest.BaseTest;
import pages.ProductQuantityPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class VerifyQuantityTest extends BaseTest {

    @Test
    public void verifyProductQuantityInCart() {

        ProductQuantityPage productPage = new ProductQuantityPage(driver);

        productPage.clickProducts();
        productPage.openFirstProduct();

        productPage.setQuantity("4");
        productPage.clickAddToCart();
        productPage.clickViewCart();

        Assert.assertEquals(productPage.getQuantityFromCart(), "4",
                "Quantity mismatch in cart!");
    }
}
